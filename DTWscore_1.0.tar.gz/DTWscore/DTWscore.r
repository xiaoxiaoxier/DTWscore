DTWscore=function(FPKM_matrix,n1,n2,p) {
  cat("Step 1: fliter unexpressed genes\n")
  filter=apply(FPKM_matrix,1,function(x) length(x[x>0.1])>0)
  a_nonzero=FPKM_matrix[filter,]
  cat("Step 2: calculate DTWscore for each gene\n")
  dis=vector()
  for(i in 1:nrow(a_nonzero)) {
    x=t(a_nonzero[i,(1:n1)])
    y=t(a_nonzero[i,((n1+1):n2)])
    dis[i]=dtw(x,y,keep=TRUE)$normalizedDistance }
  bb=cbind(a_nonzero,dis)
  aa_ordered=bb[order(bb$dis,decreasing = TRUE),]
  cat("Step 3: choose heterogeneous genes by users\n")
  j=rownames(a_nonzero[which(dis>quantile(dis,probs=seq(p,p,0.01))),])
  cat("names of highly variable genes are written in the txt file\n")
  write.table(j, file = "heterogeneous.txt", row.names = FALSE, col.names = FALSE)
  return (aa_ordered)
}
  